/**
 * Constants for WestManga source (westmanga.me)
 */
const WEST_BASE_URL = 'https://westmanga.me';

module.exports = {
    WEST_BASE_URL
};
