/**
 * Constants for WeebCentral source (weebcentral.com)
 * International manga source
 */
const WEEB_BASE_URL = 'https://weebcentral.com';

module.exports = {
    WEEB_BASE_URL
};
