/**
 * Application constants
 */
const BASE_URL = 'https://komiku.org/';

module.exports = {
  BASE_URL
}; 